<?php
/*****************************************************************************************************
Plugin Name: Personaliza tu WordPress
Description: En este plugin pondremos las funciones para personalizar nuestra instalación de WordPeess
Plugin URI: 
Version: 1.0
License: GPL
Author: Meetup WordPress Madrid
Author URI: https://oscarperez.es/
*****************************************************************************************************/

	// Pegar a partir de aquí las funciones y código que queramos añadir.

	// Eliminar la basura de la etiqueta <head> 
	remove_action('wp_head', 'wp_generator'); //elimina la version del WordPress
	remove_action('wp_head', 'wlwmanifest_link'); 
	remove_action('wp_head', 'rsd_link');  // rel="EditURI"

	/////////////////////////////////////////////////////////////////////
	// MODIFICACIONES PARA LA PAGINA DE LOGIN DEL PANEL DE ADMINISTRACION
	/////////////////////////////////////////////////////////////////////
	//cambiar el mensaje de error en el login del panel de administración
	function mensaje_de_error_en_el_login() {
		return ' ¡Soy siervo del Fuego Secreto, administrador de la llama de Anor! ¡Tu Fuego Oscuro es en vano! ¡Llama de Udûn! ¡Vuelve a la Sombra! ¡NO... PUEDES... PASAR! ';
	}
	add_filter('login_errors', 'mensaje_de_error_en_el_login');
	//cambiar el enlace del logo de la página de login de WordPress	
	function la_url_del_logo_de_wpadmin() {
	  return home_url();
	}//end my_login_logo_url()
	add_filter( 'login_headerurl', 'la_url_del_logo_de_wpadmin' );

	// Personalizar el look del login del panel de control
	// Añadimos nuestro fichero css a la página del login
	function el_login_de_wpadmin() { 
		wp_register_style('mi_login', WP_PLUGIN_URL .'/personalizar/assets/mi_login.css');
		wp_enqueue_style('mi_login');
	}
	add_action( 'login_enqueue_scripts', 'el_login_de_wpadmin' );


	//muestra un mensaje en la página de login del panel de administración
	function mensajeLogin()
	{
		return "<h2 align='center'>Bienvenido a <b>Meetup Madrid</b></h2><h3 align='center'>Por favor ingresa en tu cuenta</h3>";
	}
	add_filter( 'login_message', 'mensajeLogin' );


	//Quitar cajas del escritorio
	function quita_cajas_escritorio() {
		//if( !current_user_can('manage_options') ) { //para los usuarios no adminsitradores
			remove_action( 'welcome_panel', 'wp_welcome_panel' ); //Quitar el panel de bienvenida de WorPress en el panel de administracion

			remove_meta_box('dashboard_right_now', 'dashboard', 'normal');   // De un vistazo
			remove_meta_box('dashboard_primary', 'dashboard', 'side');   // Noticas del blog de WordPress
			remove_meta_box('dashboard_quick_press', 'dashboard', 'side');  // Borrador rápido
		//}
	} 
	add_action('wp_dashboard_setup', 'quita_cajas_escritorio' );


	//Cabiamos el icono de WordPress que se muestra en la esquina superior izquierda del panel de administración
	// Añadimos nuestro fichero css al panel de administración
	function modificar_CSS() {
		wp_register_style('mi_css', WP_PLUGIN_URL.'/personalizar/assets/mi_css.css');
		wp_enqueue_style('mi_css');
	}
	add_action('admin_print_styles', 'modificar_CSS');

	//DESACTIVAR GUTEMBERG
	add_filter('use_block_editor_for_post_type', '__return_false');
?>