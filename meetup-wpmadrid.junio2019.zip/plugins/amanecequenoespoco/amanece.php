<?php

/***************************************************************************************
Plugin Name: Amanece que no es poco
Description: Muestra en la página o entrada frases de la película Amanece que no es poco
Plugin URI: https://gist.github.com/oscarperezgomez/1aa4309a077e59ee9cd166e5d06570ee
Version: 1.0
License: GPL
Author: Oscar Pérez
Author URI: https://oscarperez.es/
****************************************************************************************/
// Pegar a partir de aquí las funciones y código que queramos añadir.

//definimos un array con las frases que queremos mostrar
$frases[0] = "¡Alcalde: todos somos contingentes, pero tú eres necesario!";
$frases[1] = "¡Se me está muriendo divinamente, te lo juro! De los años que llevo de médico nunca había visto a nadie morirse tan bien como se está muriendo tu padre. Qué irse, qué apagarse, con qué parsimonia. Estoy disfrutando que no te lo puedes ni imaginar";
$frases[2] = "¡Hombre!, es que el tema del libre albedrío viene aquí pintiparado";
$frases[3] = "Calabaza, yo te llevo en el corazón";
$frases[4] = "Déjate, déjate, que un hombre en la cama siempre es un hombre en la cama ¿eh?";
$frases[5] = "Yo es que he pensado que a mí también me gustaría ser intelectual, como no tengo nada que perder";
$frases[6] = "Y ahora, para rematar, me dicen estos amigos que ha escrito usted 'Luz de agosto', la novela de Faulkner, ¡de William Faulkner! y ¿no podía usted haber plagiado a otro? ¿es que no sabe que en este pueblo es verdadera devoción lo que hay por Faulkner?";
$frases[7] = "¿Vamos a elegir nosotras al tonto del pueblo? Es que mi hermano ya está harto.<br>No, no. Esta vez no. Es un embolao que nos metían los hombres porque decían que nosotras tenemos más sensibilidad y distinguimos mejor al tonto que podría darnos más juego. Pero este año eligen ellos, que bastante tenemos nosotras con lo nuestro";
$frases[8] = "Trae algo de Góngora, que tengo yo cuerpo de Góngora…";
$frases[9] = "Lo de dar guantazos es un esquema muy sintético que conviene utilizar poco, y utilizarlo bien. Casi en plan poético, diría yo. ¡Zas-zas! Como algo prodigioso. ¿Tú me entiendes?";
$frases[10] = "¡Buenas noches!.<br>¡Que quería yo hablarle de Dostoievski! <br>Ah, pues muy bien, encantada. Ahora mismo bajo";
$frases[11] = "Por orden del señor cura, se hace saber: Que Dios es uno y trino";
$frases[12] = "Vosotros sois unos salvajes y os vais a acordar de esta como no hagais inmediatamente flashback";

//Función que se ejecutará cuando WordPress encuentre en una página o entrada el shortcode de este plugin.
function shortcode_amanece() {
  //Esta es la frase que queremos mostrar en nuestra web
  global $frases;
  $i = random_int(0, 12);
  return "<h3>$frases[$i]</h3>";
}

//Definimos el Shortcode para este plugin. 
add_shortcode('amanece', 'shortcode_amanece');
/* En nuestra página debemos de usar el shortcode [amanece] que definimos en la anterior instrucción.
 * Esta función le indica a wordpress que si encuentra en alguna página/post el shortcode [amanece], ejecute la función shortcode_amanece
*/

?>