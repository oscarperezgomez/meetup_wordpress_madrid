<?php
/*****************************************************************************************************
Plugin Name: Cargador de mu-plugins. Meetup WordPress Madrid Junio
Description: Cargador de plugins necesarios
Plugin URI: http://oscarperez.es
Version: 1.0
License: GPL
Author: Meetup WordPress Madrid
Author URI: https://oscarperez.es/
*****************************************************************************************************/

require_once ( WPMU_PLUGIN_DIR .'/personalizar/personaliza_mi_wp.php');

